const { DateTime } = require("luxon")
const {v4: uuidv4} = require('uuid');
const stories = [
    {
        id: '1',
        title: 'A funny story',
        content: 'lorem ipsum dolor sit amet',
        author: 'Richard',
        createdAt: DateTime.now().toLocaleString(DateTime.DATETIME_SHORT)
    },
    {
        id: '2',
        title: 'It is Raining',
        content: 'lalalalalalala allalalalalallalalalala',
        author: 'Michael',
        createdAt: DateTime.local(2021, 2, 12, 18, 0).toLocaleString(DateTime.DATETIME_SHORT)
    },
    {
        id: '3',
        title: 'Learning NBAD',
        content: 'This is a few sentences that I am writing. Few sentences I am writing. Writing few sentences I am.',
        author: 'Thomas',
        createdAt: DateTime.local(2021, 2, 12, 18, 0).toLocaleString(DateTime.DATETIME_SHORT)
    }
];

exports.find = () => stories;

exports.findByID = id => stories.find(story => story.id === id);

exports.save = (story) => {
    story.id = uuidv4();
    story.createdAt = DateTime.now().toLocaleString(DateTime.DATETIME_SHORT);
    stories.push(story);
}

exports.updateByID = function(id, newStory) {
    let story = stories.find(story => story.id === id);
    if(story){
        story.title = newStory.title;
        story.content = newStory.content;
        return true;
    } else {
        return false;
    }
}

exports.deleteByID = function(id) {
    let index = stories.findIndex(story => story.id === id);
    if (index !== -1) {
        stories.splice(index, 1);
        return true;
    } else {
        return false
    }

}