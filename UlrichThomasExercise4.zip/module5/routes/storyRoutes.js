const express = require('express');
const controller = require('../controllers/storyController');

const router = express.Router();

//get /stories: send all stories to user
router.get('/', controller.index);

//get /stories/new: send html form for crreating a new story
router.get('/new', controller.new);

//post /stories: create a new story
router.post('/', controller.create);

//get /stories/:id: send details of story identifdied by id
router.get('/:id', controller.show);

//get /stories/:id/edit: send html form for editing an existing story
router.get('/:id/edit', controller.edit);

//put /stories/:id: update the story idetnifdied by id
router.put('/:id', controller.update);

//delete /stories/:uid: delete the story identified by id
router.delete('/:id', controller.delete);

module.exports = router;