const mongoose = require('mongoose');
const { Schema } = mongoose;

const artSchema = new Schema({
  title: { type: String, required: [true, 'title is required'] },
  price: { type: String, required: [true, 'price is required'] },
  condition: { type: String, required: [true, 'condition is required'] },
  offers: { type: String, required: false },
  seller: { type: String, required: [true, 'seller is required'] },
  picture: { type: String, required: [true, 'picture is required'] },
  details: { type: String, required: [true, 'details is required'], minlength: [10, 'the details should have at least 10 characters'] },
  active: { type: Boolean, required: false }
},
{
    versionKey: false
});

artSchema.index({title:'text', details:'text'});

//collection name is art in database
module.exports = mongoose.model('items', artSchema);