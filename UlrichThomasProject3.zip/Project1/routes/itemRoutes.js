const express = require('express');
const multer = require('multer');
const controller = require('../controllers/itemController');
const upload = multer({ dest: './public/images/' });
  

const router = express.Router();
router.get('/search', controller.search);

//get show items
router.get('/', controller.items);

//post story
router.post('/', upload.single('picture'), controller.create);
//get new item page
router.get('/new', controller.new);

//get item with id
router.get('/:id', controller.item);

//get item id/edit
router.get('/:id/edit', controller.edit);

//put item gets updated
router.put('/:id', controller.update);

//delete item
router.delete('/:id', controller.delete);


module.exports = router;