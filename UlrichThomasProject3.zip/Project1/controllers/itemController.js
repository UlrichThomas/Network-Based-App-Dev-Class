const model = require('../models/item');
const multer = require('multer');
const upload = multer({ dest: './public/images/'});
  

exports.items = (req, res, next)=>{
    model.find()
    .then(items=>{
        items.sort((a, b) => parseFloat(a.price) - parseFloat(b.price));
        res.render('item/items', {items});
    })
    .catch(err=>next(err));
};

exports.item = (req, res, next)=>{
    let id = req.params.id;
    //validate id
    if(!id.match(/^[0-9a-fA-F]{24}$/)){
        let err = new Error('Invalid item id');
        err.status = 400;
        return next(err);
    }
    model.findById(id)
    .then(item=>{
        if(item){
            return res.render('item/item', {item});
        } else {
            let err = new Error('Cannot find a item with id ' + id);
            err.status = 404;
            next(err);
        } 
    })
    .catch(err=>next(err));
};

exports.new = (req, res)=> {
    res.render('item/new');
};

exports.create = (req,res, next)=>{
    if(!req.file){
        return res.status(400).send('No file uploaded');
    }    
    let item = new model(req.body);
    item.offers = '0';
    item.active = true;
    item.picture = req.file.filename;
    console.log(item);
    item.save() //inserts into the database
    .then(item => res.redirect('/items'))
    .catch(err=>{
        if(err.name === 'ValidationError'){
            err.status = 400;
        }
        next(err);
    });
};

exports.edit = (req, res, next) =>{
    let id = req.params.id;
    //checks that id is valid
    if(!id.match(/^[0-9a-fA-F]{24}$/)){
        let err = new Error('Invalid item id');
        err.status = 400;
        return next(err);
    }
    model.findById(id)
    .then(item=>{
        if(item){
            return res.render('item/edit', {item});
        } else {
            let err = new Error('Cannot find a item with id ' + id);
            err.status = 404;
            next(err);
        }
    })
    .catch(err=>next(err));
};

exports.update = (req, res, next) => {
    let item = req.body;
    let id = req.params.id;

    //validation of id
    if(!id.match(/^[0-9a-fA-F]{24}$/)){
        let err = new Error('Invalid item id');
        err.status = 400;
        return next(err);
    }

    model.findByIdAndUpdate(id, item, {useFindAndModify: false, runValidators: true})
    .then(item=>{
        if(item){
            res.redirect('/items/' + id);
        } else {
            let err = new Error('Cannot find an item with id ' + id);
            err.status = 404;
            next(err);
        }
    })
    .catch(err=>{
        if(err.name === 'ValidationError'){
            err.status = 400;
        }
        next(err);
    }); 
};

exports.delete = (req, res, next) => {
    let id = req.params.id;

    //validation of id
    if(!id.match(/^[0-9a-fA-F]{24}$/)){
        let err = new Error('Invalid item id');
        err.status = 400;
        return next(err);
    }

    model.findByIdAndDelete(id, {useFindAndModify: false})
    .then(item=>{
        if(item){
            res.redirect('/items/');
        } else {
            let err = new Error('Cannot find a item with id ' + id);
            err.status = 404;
            next(err);
        }
    })
    .catch(err=>next(err));
};

exports.search = (req, res) => {
    let search = req.query.query;
    
    // Constructing the query filter
    let filter = {
        $and: [
            { active: true }, // Only active items
            {
                $or: [
                    { title: { $regex: search, $options: 'i' } },
                    { details: { $regex: search, $options: 'i' } }
                ]
            }
        ]
    };
    // Searching for items based on the constructed filter
    model.find(filter)
        .then(items => {
            res.render('item/items', { items: items });
        })
        .catch(err => next(err));
};






