const {v4: uuidv4} = require('uuid');
const items = [
    {
        id: '1',
        title: 'Sailing',
        price: '10.99',
        condition: 'New',
        offers: '0',
        seller: 'Norm the Niner',
        picture: 'Sailing.jfif',
        details: 'Sailing the seas',
        active: 'true'
    },
    {
        id: '2',
        title: 'Waves',
        price: '13.95',
        condition: 'Used',
        offers: '0',
        seller: 'Norm the Niner',
        picture: 'Waves.jfif',
        details: 'Remake of an icon',
        active: 'true'
    },
    {
        id: '3',
        title: 'Skyline',
        price: '6.79',
        condition: 'New',
        offers: '0',
        seller: 'Norm the Niner',
        picture: 'Skyline.jfif',
        details: 'A city built on a river',
        active: 'true'
    },
    {
        id: '4',
        title: 'Mountianous',
        price: '19.99',
        condition: 'Like New',
        offers: '0',
        seller: 'Norm the Niner',
        picture: 'Mountianous.jfif',
        details: 'Classic village by the mountians',
        active: 'true'
    },
    {
        id: '5',
        title: 'Town Square',
        price: '132.67',
        condition: 'New',
        offers: '0',
        seller: 'Norm the Niner',
        picture: 'townsquare.jfif',
        details: 'center of a popular town',
        active: 'true'
    },
    {
        id: '6',
        title: 'Lady at the Bench',
        price: '67.99',
        condition: 'New',
        offers: '0',
        seller: 'Norm the Niner',
        picture: 'LadyattheBench.jfif',
        details: 'A lady sitting at a bench during the sunset',
        active: 'true'
    },
];

exports.find = () => items;

exports.findByID = id => items.find(item => item.id === id);

exports.save = (item) => {
    item.id = uuidv4();
    item.offers ='0';
    item.active = 'true';
    items.push(item);
};

exports.updateByID = function(id, upItem){
    let item = items.find(item => item.id === id);
    if(item){
        item.title = upItem.title;
        item.price = upItem.price;
        item.details = upItem.details;
        item.condition = upItem.condition;
        return true;
    } else{
        return false;
    }
    
};

exports.deleteByID = function(id) {
    let index = items.findIndex(item => item.id === id);
    if (index !== -1){
        items.splice(index, 1);
        return true;
    } else {
        return false;
    }    
}

exports.search = function(search) {
    let result = [];
    items.forEach(item => {
        if (item.active === 'true'){
            if (item.title.includes(search) || item.details.includes(search)){
                result.push(item);
            }
        }
    });
    return result;
}